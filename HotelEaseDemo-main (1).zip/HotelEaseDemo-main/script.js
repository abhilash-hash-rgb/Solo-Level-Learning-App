// Core data and states
const foodMenuItems = [
  "Cheeseburger",
  "Caesar Salad",
  "Grilled Chicken",
  "French Fries",
  "Pasta Alfredo",
  "Fruit Platter"
];

let foodOrder = [];
let checkInTime = null;
let checkOutTime = null;
let checkinInterval = null;

// Receptionist Data Setup
let bookings = [
  { id: 1, guestName: "John Doe", room: "101", from: "2025-10-25", to: "2025-10-28", checkedIn: false },
  { id: 2, guestName: "Jane Smith", room: "102", from: "2025-10-26", to: "2025-10-29", checkedIn: false }
];
let currentAdmitIndex = 0;
let currentCheckoutIndex = 0;
let roomsStatus = {
  "101": "Vacant",
  "102": "Vacant",
  "103": "Vacant",
  "104": "Vacant"
};

// Manager data
let pricing = {
  roomPrice: 3000,
  servicePrice: 500
};
let staffList = [];

// Housekeeping status and tasks
let housekeepingRoomStatus = {
  "101": "Vacant",
  "102": "Vacant",
  "103": "Vacant",
  "104": "Vacant"
};
let housekeepingTasks = [
  { room: "101", task: "Clean bathroom", status: "Pending" },
  { room: "102", task: "Vacuum carpets", status: "Pending" },
  { room: "103", task: "Change linens", status: "Pending" },
  { room: "104", task: "Clean windows", status: "Pending" }
];

// Admin permissions data and defaults
let permissions = {
  "Admin": {
    "manageBookings": true,
    "admitGuests": true,
    "checkOutGuests": true,
    "updatePricing": true,
    "assignStaffRoles": true,
    "updateRoomStatus": true,
    "housekeepingTasks": true
  },
  "Manager": {
    "manageBookings": true,
    "admitGuests": false,
    "checkOutGuests": false,
    "updatePricing": true,
    "assignStaffRoles": true,
    "updateRoomStatus": false,
    "housekeepingTasks": false
  },
  "Receptionist": {
    "manageBookings": true,
    "admitGuests": true,
    "checkOutGuests": true,
    "updatePricing": false,
    "assignStaffRoles": false,
    "updateRoomStatus": true,
    "housekeepingTasks": false
  },
  "Housekeeping": {
    "manageBookings": false,
    "admitGuests": false,
    "checkOutGuests": false,
    "updatePricing": false,
    "assignStaffRoles": false,
    "updateRoomStatus": true,
    "housekeepingTasks": true
  },
  "Guest": {
    "manageBookings": false,
    "admitGuests": false,
    "checkOutGuests": false,
    "updatePricing": false,
    "assignStaffRoles": false,
    "updateRoomStatus": false,
    "housekeepingTasks": false
  }
};

// Login & Dashboard Logic
function showLogin() {
  document.getElementById("login-section").style.display = "block";
  window.scrollTo(0, document.body.scrollHeight);
  hideAllPages();
  animateSection('login-section');
}

function login() {
  const user = document.getElementById("username").value.trim();
  const pass = document.getElementById("password").value.trim();
  const role = document.getElementById("role").value;
  const errorDiv = document.getElementById("error");

  if (!user || !pass) {
    errorDiv.textContent = "Please fill in all fields.";
    return;
  }

  errorDiv.textContent = "";
  document.getElementById("login-section").style.display = "none";
  document.querySelector(".hero").style.display = "none";
  document.getElementById("dashboard").style.display = "block";
  document.getElementById("roleHeader").textContent = role + " Dashboard";

  const cardsContainer = document.getElementById("dashboard-cards");
  cardsContainer.innerHTML = "";

  if (role === "Guest") {
    cardsContainer.innerHTML = `
      <div class="col-md-4 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Book Rooms</h5>
            <p>Reserve your stay quickly and easily.</p>
            <button class="btn btn-outline-primary" onclick="showPage('guest-book-room')">Open</button>
          </div>
        </div>
      </div>
      <div class="col-md-4 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Check In/Out</h5>
            <p>Manage your stay with real-time counters.</p>
            <button class="btn btn-outline-success" onclick="showPage('guest-checkinout')">Open</button>
          </div>
        </div>
      </div>
      <div class="col-md-4 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Order Food</h5>
            <p>Choose from our delicious menu.</p>
            <button class="btn btn-outline-warning" onclick="showPage('guest-food-order')">Open</button>
          </div>
        </div>
      </div>
      <div class="col-md-4 mt-3 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Room Service</h5>
            <p>Request any assistance you need.</p>
            <button class="btn btn-outline-info" onclick="showPage('guest-room-service')">Open</button>
          </div>
        </div>
      </div>
      <div class="col-md-4 mt-3 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Feedback</h5>
            <p>Tell us about your stay.</p>
            <button class="btn btn-outline-secondary" onclick="showPage('guest-feedback')">Open</button>
          </div>
        </div>
      </div>
      <div class="col-md-4 mt-3 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Loyalty Program</h5>
            <p>Earn points and unlock exclusive rewards.</p>
            <button class="btn btn-outline-success" onclick="showPage('guest-loyalty')">Open</button>
          </div>
        </div>
      </div>
    `;
    renderFoodMenu();
  } else if (role === "Receptionist") {
    cardsContainer.innerHTML = `
      <div class="col-md-3 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Manage Bookings</h5>
            <p>Create and view bookings.</p>
            <button class="btn btn-outline-primary" onclick="showReceptionistPage('receptionist-manage-bookings')">Open</button>
          </div>
        </div>
      </div>
      <div class="col-md-3 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Admit Guests</h5>
            <p>Check in arriving guests.</p>
            <button class="btn btn-outline-success" onclick="showReceptionistPage('receptionist-admit-guests')">Open</button>
          </div>
        </div>
      </div>
      <div class="col-md-3 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Check-Out Guests</h5>
            <p>Handle guest departures.</p>
            <button class="btn btn-outline-warning" onclick="showReceptionistPage('receptionist-checkout-guests')">Open</button>
          </div>
        </div>
      </div>
      <div class="col-md-3 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Update Room Status</h5>
            <p>Change room availability.</p>
            <button class="btn btn-outline-info" onclick="showReceptionistPage('receptionist-room-status')">Open</button>
          </div>
        </div>
      </div>
      <div class="col-md-3 mt-3 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Room Allocation</h5>
            <p>Automatically allocate rooms to guests.</p>
            <button class="btn btn-outline-secondary" onclick="showReceptionistPage('receptionist-room-allocation')">Open</button>
          </div>
        </div>
      </div>
    `;
    hideAllPages();
  } else if (role === "Manager") {
    cardsContainer.innerHTML = `
      <div class="col-md-4 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Update Pricing</h5>
            <p>Modify room and service prices.</p>
            <button class="btn btn-outline-primary" onclick="showPage('manager-pricing')">Open</button>
          </div>
        </div>
      </div>
      <div class="col-md-4 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Manage Staff Roles</h5>
            <p>Assign roles and permissions.</p>
            <button class="btn btn-outline-secondary" onclick="showPage('manager-staff')">Open</button>
          </div>
        </div>
      </div>
      <div class="col-md-4 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Reports & Analytics</h5>
            <p>View performance and occupancy data.</p>
            <button class="btn btn-outline-info" onclick="showPage('manager-reports')">Open</button>
          </div>
        </div>
      </div>
    `;
    hideAllPages();
  } else if (role === "Housekeeping") {
    cardsContainer.innerHTML = `
      <div class="col-md-12 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Update Room Status</h5>
            <p>Mark rooms as cleaned or in progress.</p>
            <button class="btn btn-outline-info" onclick="showPage('housekeeping-status')">Open</button>
          </div>
        </div>
      </div>
      <div class="col-md-12 mt-3 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Today's Cleaning Tasks</h5>
            <p>View and update your daily cleaning checklist.</p>
            <button class="btn btn-outline-primary" onclick="showPage('housekeeping-tasks')">Open</button>
          </div>
        </div>
      </div>
    `;
    hideAllPages();
  } else if (role === "Admin") {
    cardsContainer.innerHTML = `
      <div class="col-md-12 fade-slide-up">
        <div class="card text-center shadow-sm animated-card">
          <div class="card-body">
            <h5>Role & Permission Management</h5>
            <p>Grant or revoke permissions for staff roles.</p>
            <button class="btn btn-outline-primary" onclick="showPage('admin-permissions')">Open</button>
          </div>
        </div>
      </div>
    `;
    hideAllPages();
  } else {
    cardsContainer.innerHTML = `<p class="text-center">Role features coming soon...</p>`;
  }
  animateSection('dashboard');
}

function hideAllPages() {
  const pages = [
    // Guest pages
    "guest-book-room",
    "guest-checkinout",
    "guest-food-order",
    "guest-room-service",
    "guest-feedback",
    "guest-loyalty",
    // Receptionist pages
    "receptionist-manage-bookings",
    "receptionist-admit-guests",
    "receptionist-checkout-guests",
    "receptionist-room-status",
    "receptionist-room-allocation",
    // Manager pages
    "manager-pricing",
    "manager-staff",
    "manager-reports",
    // Housekeeping pages
    "housekeeping-status",
    "housekeeping-tasks",
    // Admin page
    "admin-permissions"
  ];
  pages.forEach(id => {
    const el = document.getElementById(id);
    if(el){
      el.style.display = "none";
      el.classList.remove('active');
    }
  });
}

function showPage(pageId) {
  hideAllPages();
  const page = document.getElementById(pageId);
  page.style.display = "block";
  animateSection(pageId);
  window.scrollTo({top: page.offsetTop - 30, behavior: 'smooth'});
}

function animateSection(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.add('active');
}

// ----- Guest Functions -----
function submitBooking(e) {
  e.preventDefault();
  const name = document.getElementById("guestName").value;
  const roomType = document.getElementById("roomType").value;
  const checkIn = document.getElementById("checkIn").value;
  const checkOut = document.getElementById("checkOut").value;
  const msgDiv = document.getElementById("bookingMsg");

  if (new Date(checkIn) >= new Date(checkOut)) {
    msgDiv.textContent = "Error: Check-Out must be after Check-In";
    msgDiv.style.color = "red";
    return;
  }
  msgDiv.textContent = `Booking confirmed for ${name} in a ${roomType} room from ${checkIn} to ${checkOut}.`;
  msgDiv.style.color = "green";
  document.getElementById("bookRoomForm").reset();
}

function renderFoodMenu() {
  const foodMenu = document.getElementById("food-menu");
  foodMenu.innerHTML = "";
  foodMenuItems.forEach((item, i) => {
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";
    li.textContent = item;
    const btn = document.createElement("button");
    btn.textContent = "Add to Order";
    btn.className = "btn btn-outline-primary btn-sm";
    btn.onclick = () => addFoodItem(item);
    li.appendChild(btn);
    foodMenu.appendChild(li);
  });
}

function addFoodItem(item) {
  foodOrder.push(item);
  renderFoodOrder();
}

function renderFoodOrder() {
  const orderList = document.getElementById("food-order");
  orderList.innerHTML = "";
  foodOrder.forEach((item, i) => {
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";
    li.textContent = item;
    const btn = document.createElement("button");
    btn.textContent = "Remove";
    btn.className = "btn btn-outline-danger btn-sm";
    btn.onclick = () => removeFoodItem(i);
    li.appendChild(btn);
    orderList.appendChild(li);
  });
}

function removeFoodItem(index) {
  foodOrder.splice(index, 1);
  renderFoodOrder();
}

function submitFoodOrder() {
  if (foodOrder.length === 0) {
    showAlert("Add some food to order first.");
    return;
  }
  document.getElementById("foodMsg").textContent = `Order placed: ${foodOrder.join(", ")}`;
  foodOrder = [];
  renderFoodOrder();
}

function submitRoomService() {
  const req = document.getElementById("roomServiceReq").value.trim();
  const msg = document.getElementById("serviceMsg");
  if (!req) {
    msg.textContent = "Please enter a request.";
    msg.style.color = "red";
    return;
  }
  msg.textContent = "Room service request submitted. We'll attend shortly!";
  msg.style.color = "green";
  document.getElementById("roomServiceReq").value = "";
}

function submitFeedback(e) {
  e.preventDefault();
  const fb = document.getElementById("feedbackText").value.trim();
  const msg = document.getElementById("feedbackMsg");
  if (!fb) {
    msg.textContent = "Please enter your feedback.";
    msg.style.color = "red";
    return;
  }
  showModal("Thank you for your valuable feedback!");
  document.getElementById("feedbackForm").reset();
}

function checkIn() {
  if (checkInTime) return showAlert("Already checked in!");
  checkInTime = new Date();
  document.getElementById("checkinStatus").textContent = "Status: Checked In at " + checkInTime.toLocaleTimeString();
  document.getElementById("checkOutBtn").disabled = false;

  checkinInterval = setInterval(() => {
    const now = new Date();
    const diff = now - checkInTime;
    const d = Math.floor(diff / (1000 * 60 * 60 * 24));
    const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const m = Math.floor((diff / (1000 * 60)) % 60);
    const s = Math.floor((diff / 1000) % 60);
    document.getElementById("counter").textContent = `Time since check-in: ${d}d ${h}h ${m}m ${s}s`;
  }, 1000);
}

function checkOut() {
  if (!checkInTime) return showAlert("You must check in first!");
  checkOutTime = new Date();
  clearInterval(checkinInterval);
  document.getElementById("checkinStatus").textContent = "Status: Checked Out at " + checkOutTime.toLocaleTimeString();
  document.getElementById("counter").textContent = "";
  document.getElementById("checkOutBtn").disabled = true;
  showModal("Thank you for staying with us!");
  checkInTime = null;
  checkOutTime = null;
}

function showLoyaltyRewards() {
  const rewardsDiv = document.getElementById("loyaltyRewards");
  rewardsDiv.innerHTML = `
    <ul class="list-group">
      <li class="list-group-item">Earn 1 point per ₹100 spent</li>
      <li class="list-group-item">10 points = 5% off next booking</li>
      <li class="list-group-item">Exclusive member-only discounts</li>
    </ul>
  `;
}

// ----- Receptionist Functions -----
function showReceptionistPage(pageId) {
  hideAllPages();
  const page = document.getElementById(pageId);
  page.style.display = "block";
  animateSection(pageId);

  document.getElementById("admitMsg").textContent = "";
  document.getElementById("checkoutMsg").textContent = "";
  document.getElementById("roomStatusMsg").textContent = "";
  document.getElementById("allocationMsg").textContent = "";

  if(pageId === 'receptionist-manage-bookings') {
    renderBookingsList();
  }
}

function renderBookingsList() {
  const list = document.getElementById("bookingsList");
  list.innerHTML = "";
  bookings.forEach(b => {
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";
    li.textContent = `${b.guestName} - Room ${b.room} (${b.from} to ${b.to}) - ` + (b.checkedIn ? "Checked In" : "Not Checked In");
    list.appendChild(li);
  });
}

function addNewBookingForm() {
  const container = document.getElementById("newBookingFormContainer");
  container.innerHTML = `
    <form id="newBookingForm" onsubmit="submitNewBooking(event)">
      <div class="mb-3">
        <label for="newGuestName" class="form-label">Guest Name</label>
        <input type="text" id="newGuestName" class="form-control" required />
      </div>
      <div class="mb-3">
        <label for="newRoomNumber" class="form-label">Room Number</label>
        <select id="newRoomNumber" class="form-select" required>
          <option>101</option>
          <option>102</option>
          <option>103</option>
          <option>104</option>
        </select>
      </div>
      <div class="mb-3">
        <label for="newFromDate" class="form-label">From</label>
        <input type="date" id="newFromDate" class="form-control" required />
      </div>
      <div class="mb-3">
        <label for="newToDate" class="form-label">To</label>
        <input type="date" id="newToDate" class="form-control" required />
      </div>
      <button class="btn btn-success" type="submit">Add Booking</button>
    </form>
  `;
}

function submitNewBooking(e) {
  e.preventDefault();
  const name = document.getElementById("newGuestName").value;
  const room = document.getElementById("newRoomNumber").value;
  const from = document.getElementById("newFromDate").value;
  const to = document.getElementById("newToDate").value;

  if (new Date(from) >= new Date(to)) {
    showAlert("Check-out date must be after check-in date.");
    return;
  }

  bookings.push({ id: bookings.length + 1, guestName: name, room, from, to, checkedIn: false });
  showAlert("Booking added successfully!");
  document.getElementById("newBookingForm").reset();
  renderBookingsList();
}

function checkInGuest() {
  while (currentAdmitIndex < bookings.length) {
    if (!bookings[currentAdmitIndex].checkedIn) {
      bookings[currentAdmitIndex].checkedIn = true;
      roomsStatus[bookings[currentAdmitIndex].room] = "Occupied";
      document.getElementById("admitMsg").textContent = `Guest ${bookings[currentAdmitIndex].guestName} admitted to Room ${bookings[currentAdmitIndex].room}.`;
      currentAdmitIndex++;
      renderBookingsList();
      return;
    }
    currentAdmitIndex++;
  }
  document.getElementById("admitMsg").textContent = "No guests to admit.";
}

function checkOutGuest() {
  while (currentCheckoutIndex < bookings.length) {
    if (bookings[currentCheckoutIndex].checkedIn) {
      bookings[currentCheckoutIndex].checkedIn = false;
      roomsStatus[bookings[currentCheckoutIndex].room] = "Vacant";
      document.getElementById("checkoutMsg").textContent = `Guest ${bookings[currentCheckoutIndex].guestName} checked out from Room ${bookings[currentCheckoutIndex].room}.`;
      currentCheckoutIndex++;
      renderBookingsList();
      return;
    }
    currentCheckoutIndex++;
  }
  document.getElementById("checkoutMsg").textContent = "No guests to check out.";
}

function updateRoomStatus() {
  const room = document.getElementById("roomSelect").value;
  const status = document.getElementById("roomStatusSelect").value;

  if (!room || !status) {
    showAlert("Please select both room and status.");
    return;
  }

  roomsStatus[room] = status;
  document.getElementById("roomStatusMsg").textContent = `Room ${room} status updated to ${status}.`;
}

function allocateRooms() {
  const today = new Date().toISOString().slice(0, 10);
  let allocatedCount = 0;

  bookings.forEach(booking => {
    if (!booking.checkedIn && roomsStatus[booking.room] === "Vacant" && booking.from >= today) {
      roomsStatus[booking.room] = "Occupied";
      booking.checkedIn = true;
      allocatedCount++;
    }
  });

  document.getElementById("allocationMsg").textContent = allocatedCount > 0 ? `${allocatedCount} guest(s) allocated rooms.` : "No rooms allocated.";
  renderBookingsList();
}

// ----- Manager Functions -----
function submitPricing(e) {
  e.preventDefault();
  const roomPrice = Number(document.getElementById("roomPrice").value);
  const servicePrice = Number(document.getElementById("servicePrice").value);

  if (roomPrice < 0 || servicePrice < 0) {
    showAlert("Prices must be zero or positive.");
    return;
  }

  pricing.roomPrice = roomPrice;
  pricing.servicePrice = servicePrice;
  document.getElementById("pricingMsg").textContent = `Prices updated. Room: ₹${roomPrice}, Service: ₹${servicePrice}`;
  document.getElementById("pricingForm").reset();
}

function submitStaff(e) {
  e.preventDefault();
  const name = document.getElementById("staffName").value.trim();
  const role = document.getElementById("staffRole").value;
  if(!name){
    showAlert("Staff name is required.");
    return;
  }
  staffList.push({ name, role });
  document.getElementById("staffMsg").textContent = `Assigned role ${role} to staff ${name}.`;
  document.getElementById("staffForm").reset();
  renderStaffList();
}

function renderStaffList() {
  const list = document.getElementById("staffListDisplay");
  list.innerHTML = "";
  staffList.forEach(staff => {
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";
    li.textContent = `${staff.name} - ${staff.role}`;
    list.appendChild(li);
  });
}

function generateReports() {
  const totalRooms = Object.keys(roomsStatus).length;
  const occupiedRooms = Object.values(roomsStatus).filter(s => s === "Occupied").length;
  const occupancyRate = ((occupiedRooms / totalRooms) * 100).toFixed(2);
  const revenue = occupiedRooms * pricing.roomPrice;
  const staffCount = staffList.length;

  const reportText = `
Occupancy Rate: ${occupancyRate}%
Total Revenue: ₹${revenue}
Staff Employed: ${staffCount}
Rooms Occupied: ${occupiedRooms} / ${totalRooms}
  `.trim();

  document.getElementById("reportsOutput").textContent = reportText;
}

// ----- Housekeeping Functions -----
function updateHKRoomStatus() {
  const room = document.getElementById("hkRoomSelect").value;
  const status = document.getElementById("hkRoomStatusSelect").value;

  if (!room || !status) {
    showAlert("Please select both room and status.");
    return;
  }
  housekeepingRoomStatus[room] = status;
  if(status === "Cleaned"){
    markTaskCompleted(room);
  }
  document.getElementById("hkRoomStatusMsg").textContent = `Room ${room} housekeeping status updated to ${status}.`;
  refreshHousekeepingTasks();
}

function refreshHousekeepingTasks() {
  const list = document.getElementById("hkTasksList");
  list.innerHTML = "";

  housekeepingTasks.forEach(task => {
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";

    li.textContent = `Room ${task.room} - ${task.task}`;
    const statusBadge = document.createElement("span");
    statusBadge.className = "badge rounded-pill ";
    statusBadge.textContent = task.status;
    if(task.status === "Pending"){
      statusBadge.classList.add("bg-warning", "text-dark");
    } else {
      statusBadge.classList.add("bg-success");
    }
    li.appendChild(statusBadge);
    list.appendChild(li);
  });
}

function markTaskCompleted(room) {
  const task = housekeepingTasks.find(t => t.room === room && t.status === "Pending");
  if(task){
    task.status = "Completed";
  }
}

refreshHousekeepingTasks();

// ----- Admin Functions -----
function loadPermissionsTable() {
  const tbody = document.getElementById("permissionsTableBody");
  tbody.innerHTML = "";

  for(const [role, perms] of Object.entries(permissions)){
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${role}</td>
      <td><input type="checkbox" data-role="${role}" data-perm="manageBookings" ${perms.manageBookings ? "checked" : ""} /></td>
      <td><input type="checkbox" data-role="${role}" data-perm="admitGuests" ${perms.admitGuests ? "checked" : ""} /></td>
      <td><input type="checkbox" data-role="${role}" data-perm="checkOutGuests" ${perms.checkOutGuests ? "checked" : ""} /></td>
      <td><input type="checkbox" data-role="${role}" data-perm="updatePricing" ${perms.updatePricing ? "checked" : ""} /></td>
      <td><input type="checkbox" data-role="${role}" data-perm="assignStaffRoles" ${perms.assignStaffRoles ? "checked" : ""} /></td>
      <td><input type="checkbox" data-role="${role}" data-perm="updateRoomStatus" ${perms.updateRoomStatus ? "checked" : ""} /></td>
      <td><input type="checkbox" data-role="${role}" data-perm="housekeepingTasks" ${perms.housekeepingTasks ? "checked" : ""} /></td>
    `;
    tbody.appendChild(tr);
  }
}

function savePermissions() {
  const checkboxes = document.querySelectorAll("#permissionsTableBody input[type=checkbox]");
  checkboxes.forEach(cb => {
    const role = cb.getAttribute("data-role");
    const perm = cb.getAttribute("data-perm");
    permissions[role][perm] = cb.checked;
  });
  document.getElementById("permissionsMsg").textContent = "Permissions updated successfully.";
}

function logout() {
  document.getElementById("dashboard").style.display = "none";
  document.querySelector(".hero").style.display = "block";
  hideAllPages();
  document.getElementById("username").value = "";
  document.getElementById("password").value = "";
  document.getElementById("error").textContent = "";
}

// Generic alerts and modal for better UX
function showAlert(message) {
  alert(message);
}

function showModal(message) {
  const modal = document.getElementById("modalMessage");
  const content = document.getElementById("modalContent");

  content.textContent = message;
  modal.style.display = "flex";
}

function closeModal() {
  document.getElementById("modalMessage").style.display = "none";
}

// Initialize admin permissions table when page loads
document.addEventListener('DOMContentLoaded', () => {
  loadPermissionsTable();
});
